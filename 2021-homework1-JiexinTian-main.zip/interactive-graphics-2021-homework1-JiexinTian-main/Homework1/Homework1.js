"use strict";

var shadedCube = function(){

var canvas;
var gl;

var texSize = 256;         //task-7
var numPositions  = 54;    //task-1

var positionsArray = [];
var texCoordsArray = [];   //task-7
var normalsArray = [];

//task-1
var vertices = [

   vec4(-0.5, -0.5,  0.5, 1.0),      //0
   vec4(-0.5,  0.5,  0.5, 1.0),      //1
   vec4(0.5,  0.5,  0.5, 1.0),       //2
   vec4(0.5, -0.5,  0.5, 1.0),       //3
   vec4(-0.5, -0.5, -0.5, 1.0),      //4
   vec4(-0.5,  0.5, -0.5, 1.0),      //5
   vec4(0.5,  0.5, -0.5, 1.0),       //6
   vec4(0.5, -0.5, -0.5, 1.0),        //7

   vec4(-0.65, -0.65, 0.0, 1.0),     //8
   vec4(-0.65, 0.65, 0.0, 1.0),      //9
   vec4(0.65, 0.65, 0.0, 1.0),       //10
   vec4(0.65, -0.65, 0.0, 1.0),      //11

   vec4(-0.7, 0.0, -0.7, 1.0),       //12
   vec4(-0.7, 0.0, 0.7, 1.0),        //13
   vec4(0.7, 0.0, 0.7, 1.0),         //14
   vec4(0.7, 0.0, -0.7, 1.0),        //15

   vec4(0.0, -0.75, -0.75, 1.0),     //16
   vec4(0.0, -0.75, 0.75, 1.0),      //17
   vec4(0.0, 0.75, 0.75, 1.0),       //18
   vec4(0.0, 0.75, -0.75, 1.0)       //19
];


var lightPosition = vec4(1.0, 1.0, 1.0, 0.0);
var lightAmbient = vec4(0.2, 0.2, 0.2, 1.0);
var lightDiffuse = vec4(1.0, 1.0, 1.0, 1.0);
var lightSpecular = vec4(1.0, 1.0, 1.0, 1.0);


var offLightPosition = vec4(0.3, 0.3, 0.3, 0.0);    //task-4

//task-5-------------------------------------------
var materialAmbient = vec4(1.0, 0.0, 1.0, 1.0);
var materialDiffuse = vec4(1.0, 0.8, 0.0, 1.0);
var materialSpecular = vec4(1.0, 1, 1, 1.0);
var materialShininess = 90.0;
//-------------------------------------------------


var ctm;
var ambientColor, diffuseColor, specularColor;
var modelViewMatrix, projectionMatrix, nMatrix, nMatrixLoc;     //task-6&7
var viewerPos;
var program;

var xAxis = 0;
var yAxis = 1;
var zAxis = 2;
var axis = 0;
var theta = vec3(0, 0, 0);

var thetaLoc;

//task-2----------------
var startFlag = false;
var stopFlag = false;
//----------------------


//task-3----------------------------------------------------------------
var near = 0.3;
var far = 5.0;
var radius = 4.0;
var angle = 0.0;
var phi = 0.0;
var dr = 5.0 * Math.PI/180.0;

var  fovy = 45.0;        // Field-of-view in Y direction angle (in degrees)
var  aspect;             // Viewport aspect ratio

var modelViewMatrixLoc, projectionMatrixLoc;

var persFlag = false;
//----------------------------------------------------------------------


var ncylinder            //task-4
var lightFlag = false;   //task-4

var shadeFlag = true;    //task-6

//task-7---------------------------------------------------------------------------------------
var eye = vec3(2.0, 2.0, 2.0);
var at = vec3(0.5, 0.0, 0.5);
var up = vec3(0.0, 1.0, 0.0);

var normal = vec4(0.0, 1.0, 0.0, 0.0);
var tangent = vec3(1.0, 0.0, 0.0);

var texFlag = false;

// Bump Data

var data = new Array()
    for (var i = 0; i<= texSize; i++)  data[i] = new Array();
    for (var i = 0; i<= texSize; i++) for (var j=0; j<=texSize; j++)
        data[i][j] = 0.0;
    for (var i = texSize/4; i<3*texSize/4; i++) for (var j = texSize/4; j<3*texSize/4; j++)
        data[i][j] = 1.0;

// Bump Map Normals

var normalst = new Array()
    for (var i=0; i<texSize; i++)  normalst[i] = new Array();
    for (var i=0; i<texSize; i++) for ( var j = 0; j < texSize; j++)
        normalst[i][j] = new Array();
    for (var i=0; i<texSize; i++) for ( var j = 0; j < texSize; j++) {
        normalst[i][j][0] = data[i][j]-data[i+1][j];
        normalst[i][j][1] = data[i][j]-data[i][j+1];
        normalst[i][j][2] = 1;
    }

// Scale to Texture Coordinates

    for (var i=0; i<texSize; i++) for (var j=0; j<texSize; j++) {
       var d = 0;
       for(k=0;k<3;k++) d+=normalst[i][j][k]*normalst[i][j][k];
       d = Math.sqrt(d);
       for(k=0;k<3;k++) normalst[i][j][k]= 0.5*normalst[i][j][k]/d + 0.5;
    }

// Normal Texture Array

var normals = new Uint8Array(3*texSize*texSize);

    for ( var i = 0; i < texSize; i++ )
        for ( var j = 0; j < texSize; j++ )
           for(var k =0; k<3; k++)
                normals[3*texSize*i+3*j+k] = 255*normalst[i][j][k];

var texCoord = [
    vec2(0, 0),
    vec2(0, 1.5),
    vec2(0, 1.5),
    vec2(1.5, 1.5)
];


function configureTexture( image ) {
    var texture = gl.createTexture();
    gl.activeTexture(gl.TEXTURE0);
    gl.bindTexture(gl.TEXTURE_2D, texture);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGB, texSize, texSize, 0, gl.RGB, gl.UNSIGNED_BYTE, image);
    gl.generateMipmap(gl.TEXTURE_2D);
}
//-----------------------------------------------------------------------------------------------------------


//task-7
function quad(a, b, c, d) {

    var t1 = subtract(vertices[b], vertices[a]);
    var t2 = subtract(vertices[c], vertices[b]);
    var normal = cross(t1, t2);
    normal = vec3(normal);


    positionsArray.push(vertices[a]);
    texCoordsArray.push(texCoord[0]);
    normalsArray.push(normal);

    positionsArray.push(vertices[b]);
    texCoordsArray.push(texCoord[1]);
    normalsArray.push(normal);

    positionsArray.push(vertices[c]);
    texCoordsArray.push(texCoord[2]);
    normalsArray.push(normal);

    positionsArray.push(vertices[a]);
    texCoordsArray.push(texCoord[0]);
    normalsArray.push(normal);

    positionsArray.push(vertices[c]);
    texCoordsArray.push(texCoord[2]);
    normalsArray.push(normal);

    positionsArray.push(vertices[d]);
    texCoordsArray.push(texCoord[3]);
    normalsArray.push(normal);

}

//task-1
function colorCube(){

    quad(1, 0, 3, 2);
    quad(2, 3, 7, 6);
    quad(3, 0, 4, 7);
    quad(6, 5, 1, 2);
    quad(4, 5, 6, 7);
    quad(5, 4, 0, 1);

    quad(9, 8, 11, 10);
    quad(13, 12, 15, 14);
    quad(17, 16, 19, 18);
}

//task-4
function cylinder(numSlices, numStacks, caps) {

    var slices = 36;
    if(numSlices) slices = numSlices;
    var stacks = 1;
    if(numStacks) stacks = numStacks;
    var capsFlag = true;
    if(caps==false) capsFlag = caps;
    
    var data = {};
    
    var top = 0.5;
    var bottom = -0.5;
    var radius = 0.5;
    var topCenter = [0.0, top, 0.0];
    var bottomCenter = [0.0, bottom, 0.0];
    
    
    var sideColor = [1.0, 0.0, 0.0, 1.0];
    var topColor = [0.0, 1.0, 0.0, 1.0];
    var bottomColor = [0.0, 0.0, 1.0, 1.0];
    
    
    var cylinderVertexCoordinates = [];
    var cylinderNormals = [];
    var cylinderVertexColors = [];
    var cylinderTextureCoordinates = [];
    
    // side
    
    for(var j=0; j<stacks; j++) {
      var stop = bottom + (j+1)*(top-bottom)/stacks;
      var sbottom = bottom + j*(top-bottom)/stacks;
      var topPoints = [];
      var bottomPoints = [];
      var topST = [];
      var bottomST = [];
      for(var i =0; i<slices; i++) {
        var theta = 2.0*i*Math.PI/slices;
        topPoints.push([radius*Math.sin(theta), stop, radius*Math.cos(theta), 1.0]);
        bottomPoints.push([radius*Math.sin(theta), sbottom, radius*Math.cos(theta), 1.0]);
      };
    
      topPoints.push([0.0, stop, radius, 1.0]);
      bottomPoints.push([0.0,  sbottom, radius, 1.0]);
    
    
      for(var i=0; i<slices; i++) {
        var a = topPoints[i];
        var d = topPoints[i+1];
        var b = bottomPoints[i];
        var c = bottomPoints[i+1];
        var u = [b[0]-a[0], b[1]-a[1], b[2]-a[2]];
        var v = [c[0]-b[0], c[1]-b[1], c[2]-b[2]];
    
        var normal = [
          u[1]*v[2] - u[2]*v[1],
          u[2]*v[0] - u[0]*v[2],
          u[0]*v[1] - u[1]*v[0]
        ];
    
        var mag = Math.sqrt(normal[0]*normal[0] + normal[1]*normal[1] + normal[2]*normal[2])
        normal = [normal[0]/mag, normal[1]/mag, normal[2]/mag];
        cylinderVertexCoordinates.push([a[0], a[1], a[2], 1.0]);
        cylinderVertexColors.push(sideColor);
        cylinderNormals.push([normal[0], normal[1], normal[2]]);
        cylinderTextureCoordinates.push([(i+1)/slices, j*(top-bottom)/stacks]);
    
        cylinderVertexCoordinates.push([b[0], b[1], b[2], 1.0]);
        cylinderVertexColors.push(sideColor);
        cylinderNormals.push([normal[0], normal[1], normal[2]]);
        cylinderTextureCoordinates.push([i/slices, (j-1)*(top-bottom)/stacks]);
    
        cylinderVertexCoordinates.push([c[0], c[1], c[2], 1.0]);
        cylinderVertexColors.push(sideColor);
        cylinderNormals.push([normal[0], normal[1], normal[2]]);
        cylinderTextureCoordinates.push([(i+1)/slices, (j-1)*(top-bottom)/stacks]);
    
        cylinderVertexCoordinates.push([a[0], a[1], a[2], 1.0]);
        cylinderVertexColors.push(sideColor);
        cylinderNormals.push([normal[0], normal[1], normal[2]]);
        cylinderTextureCoordinates.push([(i+1)/slices, j*(top-bottom)/stacks]);
    
        cylinderVertexCoordinates.push([c[0], c[1], c[2], 1.0]);
        cylinderVertexColors.push(sideColor);
        cylinderNormals.push([normal[0], normal[1], normal[2]]);
        cylinderTextureCoordinates.push([(i+1)/slices, (j-1)*(top-bottom)/stacks]);
    
        cylinderVertexCoordinates.push([d[0], d[1], d[2], 1.0]);
        cylinderVertexColors.push(sideColor);
        cylinderNormals.push([normal[0], normal[1], normal[2]]);
        cylinderTextureCoordinates.push([(i+1)/slices, j*(top-bottom)/stacks]);
      };
    };
    
      var topPoints = [];
      var bottomPoints = [];
      for(var i =0; i<slices; i++) {
        var theta = 2.0*i*Math.PI/slices;
        topPoints.push([radius*Math.sin(theta), top, radius*Math.cos(theta), 1.0]);
        bottomPoints.push([radius*Math.sin(theta), bottom, radius*Math.cos(theta), 1.0]);
      };
      topPoints.push([0.0, top, radius, 1.0]);
      bottomPoints.push([0.0,  bottom, radius, 1.0]);
    
    if(capsFlag) {
    
    //top
    
    for(i=0; i<slices; i++) {
      normal = [0.0, 1.0, 0.0];
      var a = [0.0, top, 0.0, 1.0];
      var b = topPoints[i];
      var c = topPoints[i+1];
      cylinderVertexCoordinates.push([a[0], a[1], a[2], 1.0]);
      cylinderVertexColors.push(topColor);
      cylinderNormals.push(normal);
      cylinderTextureCoordinates.push([0, 1]);
    
      cylinderVertexCoordinates.push([b[0], b[1], b[2], 1.0]);
      cylinderVertexColors.push(topColor);
      cylinderNormals.push(normal);
      cylinderTextureCoordinates.push([0, 1]);
    
      cylinderVertexCoordinates.push([c[0], c[1], c[2], 1.0]);
      cylinderVertexColors.push(topColor);
      cylinderNormals.push(normal);
      cylinderTextureCoordinates.push([0, 1]);
    };
    
    //bottom
    
    for(i=0; i<slices; i++) {
      normal = [0.0, -1.0, 0.0];
      var a = [0.0, bottom, 0.0, 1.0];
      var b = bottomPoints[i];
      var c = bottomPoints[i+1];
      cylinderVertexCoordinates.push([a[0], a[1], a[2], 1.0]);
      cylinderVertexColors.push(bottomColor);
      cylinderNormals.push(normal);
      cylinderTextureCoordinates.push([0, 1]);
    
      cylinderVertexCoordinates.push([b[0], b[1], b[2], 1.0]);
      cylinderVertexColors.push(bottomColor);
      cylinderNormals.push(normal);
      cylinderTextureCoordinates.push([0, 1]);
    
      cylinderVertexCoordinates.push([c[0], c[1], c[2], 1.0]);
      cylinderVertexColors.push(bottomColor);
      cylinderNormals.push(normal);
      cylinderTextureCoordinates.push([0, 1]);
    };
    
    };
    function translate(x, y, z){
       for(var i=0; i<cylinderVertexCoordinates.length; i++) {
         cylinderVertexCoordinates[i][0] += x;
         cylinderVertexCoordinates[i][1] += y;
         cylinderVertexCoordinates[i][2] += z;
       };
    }
    
    function scale(sx, sy, sz){
        for(var i=0; i<cylinderVertexCoordinates.length; i++) {
            cylinderVertexCoordinates[i][0] *= sx;
            cylinderVertexCoordinates[i][1] *= sy;
            cylinderVertexCoordinates[i][2] *= sz;
            cylinderNormals[i][0] /= sx;
            cylinderNormals[i][1] /= sy;
            cylinderNormals[i][2] /= sz;
        };
    }
    
    function radians( degrees ) {
        return degrees * Math.PI / 180.0;
    }
    
    function rotate( angle, axis) {
    
        var d = Math.sqrt(axis[0]*axis[0] + axis[1]*axis[1] + axis[2]*axis[2]);
    
        var x = axis[0]/d;
        var y = axis[1]/d;
        var z = axis[2]/d;
    
        var c = Math.cos( radians(angle) );
        var omc = 1.0 - c;
        var s = Math.sin( radians(angle) );
    
        var mat = [
            [ x*x*omc + c,   x*y*omc - z*s, x*z*omc + y*s ],
            [ x*y*omc + z*s, y*y*omc + c,   y*z*omc - x*s ],
            [ x*z*omc - y*s, y*z*omc + x*s, z*z*omc + c ]
        ];
    
        for(var i=0; i<cylinderVertexCoordinates.length; i++) {
              var u = [0, 0, 0];
              var v = [0, 0, 0];
              for( var j =0; j<3; j++)
               for( var k =0 ; k<3; k++) {
                  u[j] += mat[j][k]*cylinderVertexCoordinates[i][k];
                  v[j] += mat[j][k]*cylinderNormals[i][k];
                };
               for( var j =0; j<3; j++) {
                 cylinderVertexCoordinates[i][j] = u[j];
                 cylinderNormals[i][j] = v[j];
               };
        };
    }
    
    data.TriangleVertices = cylinderVertexCoordinates;
    data.TriangleNormals = cylinderNormals;
    data.TriangleVertexColors = cylinderVertexColors;
    data.TextureCoordinates = cylinderTextureCoordinates;
    data.rotate = rotate;
    data.translate = translate;
    data.scale = scale;
    return data;
    
    }


init()

function init() {

    canvas = document.getElementById("gl-canvas");

    gl = canvas.getContext('webgl2');
    if (!gl) alert("WebGL 2.0 isn't available");

    gl.viewport(0, 0, canvas.width, canvas.height);
    aspect =  canvas.width/canvas.height;   //task-3
    gl.clearColor(1.0, 1.0, 1.0, 1.0);

    gl.enable(gl.DEPTH_TEST);


    //task-4---------------------------------------------------
    // specify objects and instance them
    var myCylinder = cylinder(8, 1, true);
    myCylinder.scale(0.2, 0.2, 0.2);
    myCylinder.rotate(45.0, [ 1, 1, 1]);
    myCylinder.translate(-0.85, 0.8, 0.0);

    // put object data in arrays that will be sent to shaders
    var pointsCylinder = myCylinder.TriangleVertices;
    var normalsCylinder = myCylinder.TriangleNormals;
    var texCoordCylinder = myCylinder.TextureCoordinates;

    // object sizes (number of vertices)
    ncylinder = myCylinder.TriangleVertices.length;

    positionsArray = positionsArray.concat(pointsCylinder);
    normalsArray = normalsArray.concat(normalsCylinder);
    texCoordsArray = texCoordsArray.concat(texCoordCylinder);
    //-----------------------------------------------------------


    //
    //  Load shaders and initialize attribute buffers
    //
    program = initShaders(gl, "vertex-shader", "fragment-shader");  
    gl.useProgram(program);
    
    //task-7--------------------------------------------------
    modelViewMatrix  = lookAt(eye, at, up);
    projectionMatrix = ortho(-1, 1, -1, 1, -100, 100);

    nMatrix = normalMatrix(modelViewMatrix, true);
    //---------------------------------------------------------

    colorCube()

    var nBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, nBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, flatten(normalsArray), gl.STATIC_DRAW);
    var normalLoc = gl.getAttribLocation(program, "aNormal");
    gl.vertexAttribPointer(normalLoc, 3, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(normalLoc);

    var vBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, vBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, flatten(positionsArray), gl.STATIC_DRAW);
    var positionLoc = gl.getAttribLocation(program, "aPosition");
    gl.vertexAttribPointer(positionLoc, 4, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(positionLoc);

    thetaLoc = gl.getUniformLocation(program, "theta");

    viewerPos = vec3(0.0, 0.0, -20.0);

    //task-3--------------------------------------------------------------------
    modelViewMatrixLoc = gl.getUniformLocation(program, "uModelViewMatrix");
    projectionMatrixLoc = gl.getUniformLocation(program, "uProjectionMatrix");
    //--------------------------------------------------------------------------
    nMatrixLoc = gl.getUniformLocation(program, "uNormalMatrix");   //task-6


    //task-7------------------------------------------------------------------
    var tBuffer = gl.createBuffer();
    gl.bindBuffer( gl.ARRAY_BUFFER, tBuffer);
    gl.bufferData( gl.ARRAY_BUFFER, flatten(texCoordsArray), gl.STATIC_DRAW);
    var texCoordLoc = gl.getAttribLocation( program, "aTexCoord");
    gl.vertexAttribPointer( texCoordLoc, 2, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(texCoordLoc);

    configureTexture(normals);
    //-------------------------------------------------------------------------

    var ambientProduct = mult(lightAmbient, materialAmbient);
    var diffuseProduct = mult(lightDiffuse, materialDiffuse);
    var specularProduct = mult(lightSpecular, materialSpecular);

    document.getElementById("ButtonX").onclick = function(){axis = xAxis;};
    document.getElementById("ButtonY").onclick = function(){axis = yAxis;};
    document.getElementById("ButtonZ").onclick = function(){axis = zAxis;};
    document.getElementById("ButtonT").onclick = function(){startFlag = !startFlag;};         //task-2
    document.getElementById("ButtonH").onclick = function(){stopFlag = !stopFlag;};           //task-2
    document.getElementById("SwitchPerspective").onclick = function(){persFlag = !persFlag;}; //task-3
    document.getElementById("SwitchShade").onclick = function(){
        shadeFlag = !shadeFlag;
        /*if(shadeFlag){
            document.getElementById('inf3').innerHTML = "Per Vertex";
        }
        else{
            document.getElementById('inf3').innerHTML = "Per Fragment";
        }*/
    };   //task-6
    document.getElementById("SwitchLight").onclick = function(){lightFlag = !lightFlag;};       //task-4
    document.getElementById("SwitchTexture").onclick = function(){texFlag = !texFlag;};         //task-7

    //task-3------------------------------------------------------------------------
    document.getElementById("zFarSlider").onchange = function(event) {
        far = event.target.value;
    };
    document.getElementById("zNearSlider").onchange = function(event) {
        near = event.target.value;
    };
    document.getElementById("radiusSlider").onchange = function(event) {
       radius = event.target.value;
    };
    document.getElementById("thetaSlider").onchange = function(event) {
        angle = event.target.value* dr;
    };
    document.getElementById("phiSlider").onchange = function(event) {
        phi = event.target.value* dr;
    };
    document.getElementById("fovSlider").onchange = function(event) {
        fovy = event.target.value;
    };
    document.getElementById("aspectSlider").onchange = function(event) {
        aspect = event.target.value;
    };
    //------------------------------------------------------------------------------


    gl.uniform4fv(gl.getUniformLocation(program, "uAmbientProduct"),
       ambientProduct);
    gl.uniform4fv( gl.getUniformLocation(program, "uDiffuseProduct"), 
       diffuseProduct);
    gl.uniform4fv( gl.getUniformLocation(program, "uSpecularProduct"),
       specularProduct );
    gl.uniform1f( gl.getUniformLocation(program, "uShininess"), 
       materialShininess);
    gl.uniform1f( gl.getUniformLocation(program, "uLightProduct"), 
       lightPosition);

    //task-6-------------------------------------------------
    gl.uniform4fv( gl.getUniformLocation(program,
        "uAmbientProductShade"),flatten(ambientProduct));
     gl.uniform4fv( gl.getUniformLocation(program,
        "uDiffuseProductShade"),flatten(diffuseProduct));
     gl.uniform4fv( gl.getUniformLocation(program,
        "uSpecularProductShade"),flatten(specularProduct));
     gl.uniform1f( gl.getUniformLocation(program,
        "uShininessShade"),materialShininess);
    //--------------------------------------------------------


   //task-7------------------------------------------------------------------  
    gl.uniform4fv( gl.getUniformLocation(program, "uNormal"), 
       normal);
    gl.uniform3fv( gl.getUniformLocation(program, "uObjTangent"), 
       tangent);
    gl.uniform4fv( gl.getUniformLocation(program, "uDiffuseProducttexture"), 
       diffuseProduct);

    gl.uniformMatrix3fv( gl.getUniformLocation(program, "uNormalMatrix"), 
       false, flatten(nMatrix));
    gl.uniformMatrix4fv( gl.getUniformLocation(program, "uProjectionMatrix"), 
       false, flatten(projectionMatrix));
   //-----------------------------------------------------------------------------
    

   render();
}

function render(){

    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);

    //task-2---------------------------------------------------------------------------
    if(startFlag) theta[axis] += 2.0;

        modelViewMatrix = mat4();
        modelViewMatrix = mult(modelViewMatrix, rotate(theta[xAxis], vec3(1, 0, 0)));
        modelViewMatrix = mult(modelViewMatrix, rotate(theta[yAxis], vec3(0, 1, 0)));
        modelViewMatrix = mult(modelViewMatrix, rotate(theta[zAxis], vec3(0, 0, 1)));

    if(stopFlag){
        startFlag = !stopFlag;
        stopFlag = startFlag;
    }
    //----------------------------------------------------------------------------------

    //task-3-----------------------------------------------------------------------------
    if(persFlag){
        eye = vec3(radius*Math.sin(angle)*Math.cos(phi),
            radius*Math.sin(angle)*Math.sin(phi), radius*Math.cos(angle));
        modelViewMatrix = lookAt(eye, at, up);
        projectionMatrix = perspective(fovy, aspect, near, far);

        gl.uniformMatrix4fv(modelViewMatrixLoc, false, flatten(modelViewMatrix));
    }
    else{
        projectionMatrix = ortho(-1, 1, -1, 1, -100, 100);
    }
    //-----------------------------------------------------------------------------

    
    //task-4-------------------------------------------------------------
    if(lightFlag){
        gl.uniform4fv( gl.getUniformLocation(program, "uLightPosition"),
            lightPosition);
    }
    else{
        gl.uniform4fv( gl.getUniformLocation(program, "uLightPosition"),
            offLightPosition);
    }
    //--------------------------------------------------------------------


    gl.uniform1i( gl.getUniformLocation(program, "uPerspectiveFlag"), persFlag);    //task-3
    gl.uniform1i( gl.getUniformLocation(program, "uLightFlag"), lightFlag);         //task-4
    gl.uniform1i( gl.getUniformLocation(program, "uShadeFlag"), shadeFlag);         //task-6
    gl.uniform1i( gl.getUniformLocation(program, "uTextureFlag"), texFlag);         //task-7

    //console.log(modelView);
    gl.uniformMatrix4fv( gl.getUniformLocation(program, "uModelViewMatrix"), false, flatten(modelViewMatrix));  
    gl.uniformMatrix4fv( gl.getUniformLocation(program, "uProjectionMatrix"), false, flatten(projectionMatrix));
    gl.uniformMatrix3fv( gl.getUniformLocation(program, "uNormalMatrix"), false, flatten(nMatrix));
    gl.uniformMatrix4fv(projectionMatrixLoc, false, flatten(projectionMatrix));
    
    gl.drawArrays( gl.TRIANGLES, 0, numPositions+ncylinder);
    requestAnimationFrame(render);
}

}
shadedCube();

