"use strict";

var canvas;
var gl;
var program;

var projectionMatrix;
var modelViewMatrix;
var instanceMatrix;
var modelViewMatrixLoc;


//task-6----------------------
var theta1 = vec3(5, 0, 0);         
var xAxis = 0;      
var yAxis = 1;      
var zAxis = 2;      
var axis = 0;
//----------------------------


/***** VERTICES  *******/

var vertices = [

    vec4( -0.5, -0.5,  0.5, 1.0 ),
    vec4( -0.5,  0.5,  0.5, 1.0 ),
    vec4( 0.5,  0.5,  0.5, 1.0 ),
    vec4( 0.5, -0.5,  0.5, 1.0 ),
    vec4( -0.5, -0.5, -0.5, 1.0 ),
    vec4( -0.5,  0.5, -0.5, 1.0 ),
    vec4( 0.5,  0.5, -0.5, 1.0 ),
    vec4( 0.5, -0.5, -0.5, 1.0 )
];



var aTorso = [0.0, -1.0, 0.0]

//task-2------------
var meadow_x = 6.0;
var meadow_y = -5.0;
var meadow_z = 0.0;
//------------------

//task-4------------
var fence_x = 8.0;
var fence_y = -2.2;
var fence_z = 0.0;
//------------------

var torsoId = 0;
var headId  = 1;
var head1Id = 1;
var head2Id = 10;
var leftUpperArmId = 2;
var leftLowerArmId = 3;
var rightUpperArmId = 4;
var rightLowerArmId = 5;
var leftUpperLegId = 6;
var leftLowerLegId = 7;
var rightUpperLegId = 8;
var rightLowerLegId = 9;
var tailId = 11;    //task-1
var fenceId = 12;   //task-4
var MeadowId = 13;  //task-2
var rotateBodyId = 14;

var torsoHeight = 2.0;
var torsoWidth = 4.0;
var headHeight = 1.0;
var headWidth = 1.0;
var tailHeight = 0.3;   //task-1
var tailWidth = 0.8;    //task-1

var upperArmHeight = 0.5;
var upperArmWidth  = 1.0;
var lowerArmHeight = 0.5;
var lowerArmWidth  = 0.3;
var upperLegHeight = 0.5;
var upperLegWidth  = 1.0;
var lowerLegHeight = 0.5;
var lowerLegWidth  = 0.3;

var MeadowIdWidth = 19.0;   //task-2
var MeadowIdHeight = 5.0;   //task-2

var fenceWidth = 1.0;       //task-4
var fenceHeight = 3.7;      //task-4




var numNodes = 15;
var numAngles = 11;
var angle = 0;

var theta = [0, 90, -180, 35, 180, -15, 180,  35, 180, -15, 45, -45, 0, 0, 0];

var numVertices = 24;

var stack = [];
var figure = [];

for( var i=0; i<numNodes; i++) figure[i] = createNode(null, null, null, null);

var vBuffer;
var modelViewLoc;

var pointsArray = [];


//--------- TEXTURE --------//

var textureB;
var textureH;
var textureM;
var textureF;

var texCoordsArray = [];
var textureFace = true;
var textureFence = true;
var textureMeadow = true;

//-- TEXTURE COORDINATES --//

var texCoord = [
    vec2(0, 0),
    vec2(0, 1),
    vec2(1, 1),
    vec2(1, 0)
];


//------------------- CONFIGURE TEXTURE ----------------------//


function configureTexture( image1,image2, image3,image4 ) {

    textureB = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, textureB);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGB,
         gl.RGB, gl.UNSIGNED_BYTE, image1);
    gl.generateMipmap(gl.TEXTURE_2D);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER,
                      gl.NEAREST_MIPMAP_LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
    
    gl.uniform1i(gl.getUniformLocation(program, "uTextureHead"), 0);


    textureH = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, textureH);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGB,
         gl.RGB, gl.UNSIGNED_BYTE, image2);
    gl.generateMipmap(gl.TEXTURE_2D);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER,
                      gl.NEAREST_MIPMAP_LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
    
    gl.uniform1i(gl.getUniformLocation(program, "uTextureBody"), 1);
    

    textureM = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, textureM);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGB,
         gl.RGB, gl.UNSIGNED_BYTE, image3);
    gl.generateMipmap(gl.TEXTURE_2D);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER,
                      gl.NEAREST_MIPMAP_LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
    
    gl.uniform1i(gl.getUniformLocation(program, "uTextureMapF"), 2);

    textureF = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, textureF);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGB,
         gl.RGB, gl.UNSIGNED_BYTE, image4);
    gl.generateMipmap(gl.TEXTURE_2D);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER,
                      gl.NEAREST_MIPMAP_LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
    
    gl.uniform1i(gl.getUniformLocation(program, "uTextureMapG"), 3);
    
}


function scale4(a, b, c) {
   var result = mat4();
   result[0] = a;
   result[5] = b;
   result[10] = c;
   return result;
}


function createNode(transform, render, sibling, child){
    var node = {
    transform: transform,
    render: render,
    sibling: sibling,
    child: child,
    }
    return node;
}


function initNodes(Id) {

    var m = mat4();

    switch(Id) {

    case torsoId:
        m = translate(aTorso[0], aTorso[1], aTorso[2])
        m = mult(m, rotate(theta[torsoId], vec3(0, 1, 0)));
        m = mult(m, rotate(theta[rotateBodyId], vec3(0, 0, 1)));
        figure[torsoId] = createNode( m, torso, null, headId );
        break;

    case headId:
    case head1Id:
    case head2Id:

        m = translate(2.65, -0.35*headHeight+torsoHeight, 0.0);  
        m = mult(m, rotate(theta[head1Id], vec3(1, 0, 0)))
        m = mult(m, rotate(theta[head2Id], vec3(0, 1, 0)));
        m = mult(m, translate(0.0, -0.5*headHeight, 0.0));
        figure[headId] = createNode( m, head, leftUpperArmId, null);
        break;

    case leftUpperArmId:

        m = translate((0.8*torsoHeight/3), 0.06*torsoWidth, 1.0);
        m = mult(m, rotate(theta[leftUpperArmId], vec3(0, 0, 1)));
        figure[leftUpperArmId] = createNode( m, leftUpperArm, rightUpperArmId, leftLowerArmId );
        break;

    case rightUpperArmId:

        m = translate(0.7*torsoHeight/2, 0.1*torsoWidth, -1.0); 
        m = mult(m, rotate(theta[rightUpperArmId], vec3(0, 0, 1)));
        figure[rightUpperArmId] = createNode( m, rightUpperArm, leftUpperLegId, rightLowerArmId );
        break;

    case leftUpperLegId:

        m = translate(-(0.3*torsoHeight/3+upperLegWidth), 0.8*upperLegHeight, -1.0);
        m = mult(m , rotate(theta[leftUpperLegId], vec3(0, 0, 1)));
        figure[leftUpperLegId] = createNode( m, leftRearUpLeg, rightUpperLegId, leftLowerLegId );
        break;

    case rightUpperLegId:

        m = translate(-(1.4*torsoHeight/3+0.1*upperLegWidth), 0.5*upperLegHeight, 1.0);
        m = mult(m, rotate(theta[rightUpperLegId], vec3(0, 0, 1)));
        figure[rightUpperLegId] = createNode( m, rightRearUpLeg, tailId, rightLowerLegId );     //task-1
    break;

    case leftLowerArmId:

        m = translate(0.0, upperArmHeight, 0.0);
        m = mult(m, rotate(theta[leftLowerArmId], vec3(0, 0, 1)));
        figure[leftLowerArmId] = createNode( m, leftFrontDownLeg, null, null );
        break;

    case rightLowerArmId:

        m = translate(0.0, upperArmHeight, 0.0);
        m = mult(m, rotate(theta[rightLowerArmId], vec3(0, 0, 1)));
        figure[rightLowerArmId] = createNode( m, rightFrontDownLeg, null, null );
        break;

    case leftLowerLegId:

        m = translate(0.0, upperLegHeight, 0.0);
        m = mult(m, rotate(theta[leftLowerLegId],vec3(0, 0, 1)));
        figure[leftLowerLegId] = createNode( m, leftRearDownLeg, null, null );
        break;

    case rightLowerLegId:

        m = translate(0.0, upperLegHeight, 0.0);
        m = mult(m, rotate(theta[rightLowerLegId], vec3(0, 0, 1)));
        figure[rightLowerLegId] = createNode( m, rightRearDownLeg, null, null );
        break;

    //task-1---------------------------------------------------
    case tailId:
        m = translate(-2.25, tailHeight+0.3*torsoHeight, 0.0);
        m = mult(m, rotate(theta[tailId], vec3(0, 0, 1)));
        figure[tailId] = createNode( m, tail, null, null );
        break;
    //----------------------------------------------------------


    //task-4----------------------------------------------------------
    case fenceId:

        //m = translate(15.5, -fenceHeight, 0.0);
        m = translate(fence_x, fence_y, fence_z);
        m = mult(m, rotate(theta[fenceId], vec3(0, 1, 0)));
        figure[fenceId] = createNode( m, fence, MeadowId, null );
        break;
    //----------------------------------------------------------------


    //task-2----------------------------------------------------------------
    case MeadowId:

        //m = translate(13.1, -(MeadowIdWidth - 0.2*MeadowIdHeight), 1.0);
        m = translate(meadow_x, meadow_y, meadow_z)
        m = mult(m, rotate(theta[MeadowId], vec3(1, 0, 0)));
        figure[MeadowId] = createNode( m, meadow, null, null );
        break;
    //-----------------------------------------------------------------------

    }
}


function traverse(Id) {

   if(Id == null) return;
   stack.push(modelViewMatrix);
   modelViewMatrix = mult(modelViewMatrix, figure[Id].transform);
   figure[Id].render();
   if(figure[Id].child != null) traverse(figure[Id].child);
    modelViewMatrix = stack.pop();
   if(figure[Id].sibling != null) traverse(figure[Id].sibling);
}


function torso() {
 
    textureFace = true;
    textureMeadow = false;
    textureFence = false;
    gl.uniform1f( gl.getUniformLocation(program, "textureFace"), textureFace );
    gl.uniform1f( gl.getUniformLocation(program, "textureFence"), textureFence );
    gl.uniform1f( gl.getUniformLocation(program, "textureMeadow"), textureMeadow);
    
    instanceMatrix = mult(modelViewMatrix, translate(0.0, 0.35*torsoWidth  , 0.0) );
    instanceMatrix = mult(instanceMatrix, scale( torsoWidth, torsoHeight, torsoHeight));
    gl.uniformMatrix4fv(modelViewMatrixLoc, false, flatten(instanceMatrix) );
    for(var i =0; i<6; i++) gl.drawArrays(gl.TRIANGLE_FAN, 4*i, 4);
}

function head() {

    textureFace = false;
    textureMeadow = false;
    textureFence = false;
    gl.uniform1f( gl.getUniformLocation(program, "textureFace"), textureFace );
    gl.uniform1f( gl.getUniformLocation(program, "textureFence"), textureFence );
    gl.uniform1f( gl.getUniformLocation(program, "textureMeadow"), textureMeadow);

    instanceMatrix = mult(modelViewMatrix, translate(0.0, 0.5 * headHeight, 0.0 ));
	instanceMatrix = mult(instanceMatrix, scale(headWidth, headHeight, headWidth) );
    gl.uniformMatrix4fv(modelViewMatrixLoc, false, flatten(instanceMatrix) );
    for(var i =0; i<6; i++) gl.drawArrays(gl.TRIANGLE_FAN, 4*i, 4);
}


function leftUpperArm() {

    textureFace = true;
    textureMeadow = false;
    textureFence = false;
    gl.uniform1f( gl.getUniformLocation(program, "textureFace"), textureFace );
    gl.uniform1f( gl.getUniformLocation(program, "textureFence"), textureFence );
    gl.uniform1f( gl.getUniformLocation(program, "textureMeadow"), textureMeadow);
    
    instanceMatrix = mult(modelViewMatrix, translate(0.0, 0.5 * upperArmHeight, 0.0) );
	instanceMatrix = mult(instanceMatrix, scale(upperArmWidth, upperArmHeight, upperArmWidth) );
    gl.uniformMatrix4fv(modelViewMatrixLoc, false, flatten(instanceMatrix) );
    for(var i =0; i<6; i++) gl.drawArrays(gl.TRIANGLE_FAN, 4*i, 4);
}

function leftFrontDownLeg() {
 
    textureFace = true;
    textureMeadow = false;
    textureFence = false;
    gl.uniform1f( gl.getUniformLocation(program, "textureFace"), textureFace );
    gl.uniform1f( gl.getUniformLocation(program, "textureFence"), textureFence );
    gl.uniform1f( gl.getUniformLocation(program, "textureMeadow"), textureMeadow);
    
    instanceMatrix = mult(modelViewMatrix, translate(0.0, 0.5 * lowerArmHeight, 0.0) );
	instanceMatrix = mult(instanceMatrix, scale(lowerArmWidth, lowerArmHeight, lowerArmWidth) );
    gl.uniformMatrix4fv(modelViewMatrixLoc, false, flatten(instanceMatrix) );
    for(var i =0; i<6; i++) gl.drawArrays(gl.TRIANGLE_FAN, 4*i, 4);
}

function rightUpperArm() {
  
    textureFace = true;
    textureMeadow = false;
    textureFence = false;
    gl.uniform1f( gl.getUniformLocation(program, "textureFace"), textureFace );
    gl.uniform1f( gl.getUniformLocation(program, "textureFence"), textureFence );
    gl.uniform1f( gl.getUniformLocation(program, "textureMeadow"), textureMeadow);
    
    instanceMatrix = mult(modelViewMatrix, translate(0.0, 0.5 * upperArmHeight, 0.0) );
	instanceMatrix = mult(instanceMatrix, scale(upperArmWidth, upperArmHeight, upperArmWidth) );
    gl.uniformMatrix4fv(modelViewMatrixLoc, false, flatten(instanceMatrix) );
    for(var i =0; i<6; i++) gl.drawArrays(gl.TRIANGLE_FAN, 4*i, 4);
}

function rightFrontDownLeg() {
   
    textureFace = true;
    textureMeadow = false;
    textureFence = false;
    gl.uniform1f( gl.getUniformLocation(program, "textureFace"), textureFace );
    gl.uniform1f( gl.getUniformLocation(program, "textureFence"), textureFence );
    gl.uniform1f( gl.getUniformLocation(program, "textureMeadow"), textureMeadow);
    
    instanceMatrix = mult(modelViewMatrix, translate(0.0, 0.5 * lowerArmHeight, 0.0) );
	instanceMatrix = mult(instanceMatrix, scale(lowerArmWidth, lowerArmHeight, lowerArmWidth) );
    gl.uniformMatrix4fv(modelViewMatrixLoc, false, flatten(instanceMatrix) );
    for(var i =0; i<6; i++) gl.drawArrays(gl.TRIANGLE_FAN, 4*i, 4);
}

function  leftRearUpLeg() {
  
    textureFace = true;
    textureMeadow = false;
    textureFence = false;
    gl.uniform1f( gl.getUniformLocation(program, "textureFace"), textureFace );
    gl.uniform1f( gl.getUniformLocation(program, "textureFence"), textureFence );
    gl.uniform1f( gl.getUniformLocation(program, "textureMeadow"), textureMeadow);
    
    instanceMatrix = mult(modelViewMatrix, translate(0.0, 0.5 * upperLegHeight, 0.0) );
	instanceMatrix = mult(instanceMatrix, scale(upperLegWidth, upperLegHeight, upperLegWidth) );
    gl.uniformMatrix4fv(modelViewMatrixLoc, false, flatten(instanceMatrix) );
    for(var i =0; i<6; i++) gl.drawArrays(gl.TRIANGLE_FAN, 4*i, 4);
}

function leftRearDownLeg() {
  
    textureFace = true;
    textureMeadow = false;
    textureFence = false;
    gl.uniform1f( gl.getUniformLocation(program, "textureFace"), textureFace );
    gl.uniform1f( gl.getUniformLocation(program, "textureFence"), textureFence );
    gl.uniform1f( gl.getUniformLocation(program, "textureMeadow"), textureMeadow);
    
    instanceMatrix = mult(modelViewMatrix, translate( 0.0, 0.5 * lowerLegHeight, 0.0) );
	instanceMatrix = mult(instanceMatrix, scale(lowerLegWidth, lowerLegHeight, lowerLegWidth) );
    gl.uniformMatrix4fv(modelViewMatrixLoc, false, flatten(instanceMatrix) );
    for(var i =0; i<6; i++) gl.drawArrays(gl.TRIANGLE_FAN, 4*i, 4);
}

function rightRearUpLeg() {
  
    textureFace = true;
    textureMeadow = false;
    textureFence = false;
    gl.uniform1f( gl.getUniformLocation(program, "textureFace"), textureFace );
    gl.uniform1f( gl.getUniformLocation(program, "textureFence"), textureFence );
    gl.uniform1f( gl.getUniformLocation(program, "textureMeadow"), textureMeadow);
    
    instanceMatrix = mult(modelViewMatrix, translate(0.0, 0.5 * upperLegHeight, 0.0) );
	instanceMatrix = mult(instanceMatrix, scale(upperLegWidth, upperLegHeight, upperLegWidth) );
    gl.uniformMatrix4fv(modelViewMatrixLoc, false, flatten(instanceMatrix) );
    for(var i =0; i<6; i++) gl.drawArrays(gl.TRIANGLE_FAN, 4*i, 4);
}

function rightRearDownLeg() {
   
    textureFace = true;
    textureMeadow = false;
    textureFence = false;
    gl.uniform1f( gl.getUniformLocation(program, "textureFace"), textureFace );
    gl.uniform1f( gl.getUniformLocation(program, "textureFence"), textureFence );
    gl.uniform1f( gl.getUniformLocation(program, "textureMeadow"), textureMeadow);
    
    instanceMatrix = mult(modelViewMatrix, translate(0.0, 0.5 * lowerLegHeight, 0.0) );
	instanceMatrix = mult(instanceMatrix, scale(lowerLegWidth, lowerLegHeight, lowerLegWidth) )
    gl.uniformMatrix4fv(modelViewMatrixLoc, false, flatten(instanceMatrix) );
    for(var i =0; i<6; i++) gl.drawArrays(gl.TRIANGLE_FAN, 4*i, 4);
}

//task-1-----------------------------------------------------------------------------
function tail() {
  
    textureFace = true;
    textureMeadow = false;
    textureFence = false;
    gl.uniform1f( gl.getUniformLocation(program, "textureFace"), textureFace );
    gl.uniform1f( gl.getUniformLocation(program, "textureFence"), textureFence );
    gl.uniform1f( gl.getUniformLocation(program, "textureMeadow"), textureMeadow);
    
    instanceMatrix = mult(modelViewMatrix, translate(0.0, 0.5 * tailHeight, 0.0) );
	instanceMatrix = mult(instanceMatrix, scale(tailWidth, tailHeight, tailWidth) )
    gl.uniformMatrix4fv(modelViewMatrixLoc, false, flatten(instanceMatrix) );
    for(var i =0; i<6; i++) gl.drawArrays(gl.TRIANGLE_FAN, 4*i, 4);
}
//------------------------------------------------------------------------------------


//task-4----------------------------------------------------------------------------------
function fence() {
  
    textureFace = false;
    textureMeadow = false;
    textureFence = true;
    gl.uniform1f( gl.getUniformLocation(program, "textureFace"), textureFace );
    gl.uniform1f( gl.getUniformLocation(program, "textureFence"), textureFence );
    gl.uniform1f( gl.getUniformLocation(program, "textureMeadow"), textureMeadow);

    instanceMatrix = mult(modelViewMatrix, translate(0.0, 0.5 * fenceHeight, 0.0) );
	instanceMatrix = mult(instanceMatrix, scale(fenceWidth, fenceHeight, fenceWidth) )
    gl.uniformMatrix4fv(modelViewMatrixLoc, false, flatten(instanceMatrix) );
    for(var i =0; i<6; i++) gl.drawArrays(gl.TRIANGLE_FAN, 4*i, 4);
}
//------------------------------------------------------------------------------------------


//task-2-------------------------------------------------------------------------------------------
function meadow(){

    textureFace =false;
    textureMeadow = true;
    textureFence = false;
    gl.uniform1f( gl.getUniformLocation(program, "textureFace"), textureFace );
    gl.uniform1f( gl.getUniformLocation(program, "textureFence"), textureFence );
    gl.uniform1f( gl.getUniformLocation(program, "textureMeadow"), textureMeadow);
    
    instanceMatrix = mult(modelViewMatrix, translate(0.0, 0.5 * MeadowIdHeight, 0.0) );
	//instanceMatrix = mult(instanceMatrix, scale(MeadowIdWidth, MeadowIdHeight, MeadowIdWidth) )
    instanceMatrix = mult(instanceMatrix, scale(MeadowIdWidth, 0.1, MeadowIdWidth) )
    gl.uniformMatrix4fv(modelViewMatrixLoc, false, flatten(instanceMatrix) );
    for(var i =0; i<6; i++) gl.drawArrays(gl.TRIANGLE_FAN, 4*i, 4);
}
//task-1-----------------------------------------------------------------------------------------------


function quad(a, b, c, d) {
        
     pointsArray.push(vertices[a]);
     texCoordsArray.push(texCoord[0]);

     pointsArray.push(vertices[b]);
     texCoordsArray.push(texCoord[1]);

     pointsArray.push(vertices[c]);
     texCoordsArray.push(texCoord[2]);

     pointsArray.push(vertices[d]);
     texCoordsArray.push(texCoord[3]);
     
}


function cube()
{
    quad( 1, 0, 3, 2 );
    quad( 2, 3, 7, 6 );
    quad( 3, 0, 4, 7 );
    quad( 6, 5, 1, 2 );
    quad( 4, 5, 6, 7 );
    quad( 5, 4, 0, 1 );
}



window.onload = function init() {

    canvas = document.getElementById( "gl-canvas" );

    gl = canvas.getContext('webgl2');
    if (!gl) { alert( "WebGL 2.0 isn't available" ); }

    gl.viewport( 0, 0, canvas.width, canvas.height );
    gl.clearColor( 1.0, 1.0, 1.0, 1.0 );

    program = initShaders( gl, "vertex-shader", "fragment-shader");

    gl.useProgram(program);


    instanceMatrix = mat4();
    projectionMatrix = ortho(-5.0,20.0,-15.0, 15.0,-10.0,10.0);


    //gl.uniformMatrix4fv(gl.getUniformLocation( program, "modelViewMatrix"), false, flatten(modelViewMatrix)  );
    gl.uniformMatrix4fv( gl.getUniformLocation( program, "projectionMatrix"), false, flatten(projectionMatrix)  );

    modelViewMatrixLoc = gl.getUniformLocation(program, "modelViewMatrix")

    //---------------- IMG FOR TEXTURE ------------------//

    var image1 = document.getElementById("texImage1");
    var image2 = document.getElementById("texImage2");
    var image3 = document.getElementById("texImage3");
    var image4 = document.getElementById("texImage4");

    cube();

    //task-6---------------------------------------------------------     
    
    document.getElementById("IncreaseX").onclick = function(){
        theta1[xAxis] +=0.5;
    };
    document.getElementById("DecreaseX").onclick = function(){
        theta1[xAxis] -=0.5;
    };
    document.getElementById("IncreaseY").onclick = function(){
        theta1[yAxis] +=0.5;
    ;};
    document.getElementById("DecreaseY").onclick = function(){
        theta1[yAxis] -=0.5;
    ;};
    document.getElementById("IncreaseZ").onclick = function(){
        theta1[zAxis] +=0.5;
    ;};
    document.getElementById("DecreaseZ").onclick = function(){
   
        theta1[zAxis] -=0.5;
    ;};
    //----------------------------------------------------------------



    vBuffer = gl.createBuffer();
    gl.bindBuffer( gl.ARRAY_BUFFER, vBuffer );
    gl.bufferData(gl.ARRAY_BUFFER, flatten(pointsArray), gl.STATIC_DRAW);

    var positionLoc = gl.getAttribLocation( program, "aPosition" );
    gl.vertexAttribPointer( positionLoc, 4, gl.FLOAT, false, 0, 0 );
    gl.enableVertexAttribArray( positionLoc );


    //------------------------------- TEXTURE --------------------------------//

    var tBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, tBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, flatten(texCoordsArray), gl.STATIC_DRAW);

    var texCoordLoc = gl.getAttribLocation(program, "aTexCoord");
    gl.vertexAttribPointer(texCoordLoc, 2, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(texCoordLoc);


    //task-5------------------------------------------------------
    
    document.getElementById("Start").onclick = function(event) {
        setInterval(function() {
            go();
        }, 150);
        
    };

    document.getElementById("Reset").onclick = function(event) {
        reset();
    };
    //-------------------------------------------------------------


    //-------- CONFIGURE AND ACTIVE DIFFERENT TEXTURE ---------//
   
    configureTexture(image1,image2, image3, image4);
    
    gl.activeTexture(gl.TEXTURE0);
    gl.bindTexture(gl.TEXTURE_2D, textureB);

    gl.activeTexture(gl.TEXTURE1);
    gl.bindTexture(gl.TEXTURE_2D, textureH);

    gl.activeTexture(gl.TEXTURE2);
    gl.bindTexture(gl.TEXTURE_2D, textureM);

    gl.activeTexture(gl.TEXTURE3);
    gl.bindTexture(gl.TEXTURE_2D, textureF);


    for(i=0; i<numNodes; i++) initNodes(i);


    render();
}


//task-5-------------------------------------------
var move = true;
var up = false;

function go(){
    if (aTorso[0]<3.2){
        
        aTorso[0] +=1.0;
        initNodes(torsoId);

        if (move){
            
            theta[head2Id]+=20;
            initNodes(head2Id);

            theta[leftUpperArmId] += -25;
            initNodes(leftUpperArmId);

            theta[rightUpperArmId] += 25;
            initNodes(rightUpperArmId);

            theta[leftUpperLegId] +=-25;
            initNodes(leftUpperLegId);

            theta[rightUpperLegId] +=25;
            initNodes(rightUpperLegId);
            
            if (theta[leftUpperArmId] == -205){
                move = false;
            }
        }
        else{

            theta[head2Id]+=-20;
            initNodes(head2Id);

            theta[leftUpperArmId] += 25;
            initNodes(leftUpperArmId);

            theta[rightUpperArmId] += -25;
            initNodes(rightUpperArmId);

            theta[leftUpperLegId] +=25;
            initNodes(leftUpperLegId);

            theta[rightUpperLegId] +=-25;
            initNodes(rightUpperLegId);

            if (theta[leftUpperArmId] == -180){
                move = true;
                up = true;
            }
        }
        
    }
    else{

        if(up){

            if (theta[rotateBodyId]!= -60){
                theta[rotateBodyId] -=15;
                aTorso[1]+=0.5;
                initNodes(torsoId);

                theta[leftUpperArmId] +=10;
                initNodes(leftUpperArmId);
            
                theta[rightUpperArmId] +=20; 
                initNodes(rightUpperArmId);

                theta[leftUpperLegId] +=10;
                initNodes(leftUpperLegId);
                
                theta[rightUpperLegId] +=20;
                initNodes(rightUpperLegId);

                up = false;

            }
        }
        else{

            if(aTorso[0]<11.5){

                aTorso[1] = 3.5;

                theta[rotateBodyId] = -25;

                theta[leftUpperArmId] = 180;
                initNodes(leftUpperArmId);

                theta[rightUpperArmId] = 180;
                initNodes(rightUpperArmId);

                theta[leftUpperLegId] = 180;
                initNodes(leftUpperLegId);

                theta[rightUpperLegId] = 180;
                initNodes(rightUpperLegId);
                
                aTorso[0] +=1.0;
                initNodes(torsoId);

                theta[rotateBodyId] = 5;
            }
            else{

                aTorso[1] =-1.0;
                initNodes(torsoId);

                theta[rotateBodyId] = 0;

                theta[head2Id] = 20;
                initNodes(head2Id);

            }
           
        }
    }
    
}



function reset(){
    window.location.reload();
}
//-----------------------------------------------------------------



var render = function() {

    
        gl.clear( gl.COLOR_BUFFER_BIT );
        
        //task-6-----------------------------------------------------------------------
        modelViewMatrix = mat4();
        modelViewMatrix = mult(modelViewMatrix, rotate(theta1[xAxis], vec3(1, 0, 0)));
        modelViewMatrix = mult(modelViewMatrix, rotate(theta1[yAxis], vec3(0, 1, 0)));
        modelViewMatrix = mult(modelViewMatrix, rotate(theta1[zAxis], vec3(0, 0, 1)));
        //-----------------------------------------------------------------------------

        //gl.uniformMatrix4fv(gl.getUniformLocation(program, "modelViewMatrix"), false, flatten(modelViewMatrix));

        
        // CALL 2 TRAVERSE FOR 2 DIFFERENT STRUCTURE //
        traverse(torsoId);
        traverse(fenceId);  //task-4

        requestAnimationFrame(render);
}